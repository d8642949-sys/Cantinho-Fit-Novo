# Cantinho Fit+ (projeto Android novo)

Aplicativo Android independente, com interface local em WebView e recursos de treino, jogos, perfil, mensagens e chamadas em fase inicial.

## Estrutura

- `.github/workflows/build-cantinho-fit.yml`: workflow para compilar o APK com GitHub Actions.
- `CantinhoFitNovo/`: projeto Android Gradle.
- `CantinhoFitNovo/app/src/main/assets/site/`: interface e recursos visuais locais.

## Gerar o APK

O GitHub Actions compila o projeto quando os arquivos `CantinhoFitNovo/**` e o workflow são enviados à branch `main`, ou por execução manual em **Actions → Build Cantinho Fit+ APK → Run workflow**.

O resultado aparece em **Artifacts → Cantinho-Fit-Novo-APK**. O artifact é um ZIP que contém `app-debug.apk`.

**Não envie somente este ZIP ao GitHub esperando que o GitHub o extraia.** Extraia o pacote e envie a estrutura interna, mantendo a pasta `.github` na raiz do repositório.

## Comunicação entre aparelhos

O app usa PeerJS para sinalização e WebRTC para conexão direta. Por padrão, PeerJS usa o serviço cloud público e STUN público. Uma parte pequena dos pares pode não conseguir atravessar NAT simétrico sem TURN; o app inclui campos para configuração de TURN. Mensagens não são sincronizadas em nuvem e chamadas precisam de teste real em dois aparelhos.

Veja `LEIA-ME-PRIMEIRO.txt` antes de gerar o APK.
